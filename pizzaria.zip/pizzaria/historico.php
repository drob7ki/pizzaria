<?php

// Inicia a sessão para acessar dados do usuário autenticado
session_start();

// Verifica se o usuário está logado; se não, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para conexão com o banco de dados
include 'config.php';

// Monta a consulta SQL para buscar o histórico de entregas
// Traz TODOS os dados do pedido (sabor, tamanho, borda, massa e quantidade) e do cliente (nome, CPF, telefone e e-mail)
// A consulta une as tabelas entregas, pedidos e cliente seguindo os relacionamentos:
// entregas.pedido_id -> pedidos.id e pedidos.cliente_id -> cliente.id
// Os registros são ordenados pela data da entrega (do mais antigo para o mais novo)
// Prova 01 (por dia): ORDER BY p.data
// Prova 02 (por mês): ORDER BY MONTH(p.data), p.data
// Prova 03 (por ano): ORDER BY YEAR(p.data), p.data
$sql = "SELECT p.id, p.data, p.descricao, p.valor,
               c.sabor, c.tamanho, c.borda, c.massa, c.quantidade,
               d.nome AS cliente_nome, CAST(AES_DECRYPT(d.cpf, '$chave') AS CHAR) AS cliente_cpf,
               d.telefone, d.email
        FROM entregas p
        JOIN pedidos c ON p.pedido_id = c.id
        JOIN cliente d ON c.cliente_id = d.id
        ORDER BY p.data";

// Executa a consulta no banco de dados
$result = $conn->query($sql);
?>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<!-- Título da página -->
<h2>Histórico de Entregas</h2>

<!-- Tabela para exibir o histórico com todos os dados da entrega, do pedido e do cliente -->
<table border="1" cellpadding="5">
    <tr>
        <th>ID</th>
        <th>Data</th>
        <th>Entrega</th>
        <th>Valor (R$)</th>
        <th>Sabor</th>
        <th>Tamanho</th>
        <th>Borda</th>
        <th>Massa</th>
        <th>Qtd</th>
        <th>Cliente</th>
        <th>CPF</th>
        <th>Telefone</th>
        <th>E-mail</th>
        <th>Ações</th>
    </tr>

    <!-- Iteração sobre cada registro retornado do banco para popular as linhas da tabela -->
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
        <!-- Exibe o ID da entrega -->
        <td><?= intval($row['id']) ?></td>
        <!-- Exibe a data da entrega no formato dia/mês/ano -->
        <td><?= date('d/m/Y', strtotime($row['data'])) ?></td>
        <!-- Exibe a descrição da entrega realizada -->
        <td><?= htmlspecialchars($row['descricao']) ?></td>
        <!-- Exibe o valor da entrega com duas casas decimais -->
        <td><?= number_format($row['valor'], 2, ',', '.') ?></td>
        <!-- Dados do pedido -->
        <td><?= htmlspecialchars($row['sabor']) ?></td>
        <td><?= htmlspecialchars($row['tamanho']) ?></td>
        <td><?= htmlspecialchars($row['borda'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['massa'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['quantidade'] ?? '') ?></td>
        <!-- Dados do cliente (o CPF aparece descriptografado) -->
        <td><?= htmlspecialchars($row['cliente_nome']) ?></td>
        <td><?= htmlspecialchars($row['cliente_cpf'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['telefone'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
        <td>
            <!-- Link para editar a entrega (atualizar a data), passando o ID via GET -->
            <a href="editar_entrega.php?id=<?= $row['id'] ?>">Editar</a>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- Link para voltar à página principal do sistema -->
<a href="principal.php">Voltar</a>
