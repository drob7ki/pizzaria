<?php

// Inicia a sessão para acessar os dados do usuário logado
session_start();

// Verifica se o usuário está autenticado; caso contrário, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para estabelecer a conexão com a base de dados
include 'config.php';

// Recebe o ID do pedido a ser editado via parâmetro GET na URL; se não informado, assume 0
$id = $_GET['id'] ?? 0;

// Prepara e executa uma consulta para buscar os dados do pedido com o ID informado
$sql = "SELECT * FROM pedidos WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
$pedido = $res->fetch_assoc();

// Se não encontrou o pedido, exibe mensagem e termina a execução
if (!$pedido) {
    echo "Pedido não encontrado.";
    exit();
}

// Processa o formulário quando enviado via POST para atualizar o pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Coleta os dados atualizados do formulário
    $cliente_id = $_POST['cliente_id'];
    $sabor = $_POST['sabor'];
    $tamanho = $_POST['tamanho'];
    $borda = $_POST['borda'];
    $massa = $_POST['massa'];
    $quantidade = $_POST['quantidade'];

    // Validação simples: cliente, sabor e tamanho são obrigatórios
    if (!$cliente_id || !$sabor || !$tamanho) {
        echo "Cliente, sabor e tamanho são obrigatórios.";
    } else {
        // Atualiza os dados do pedido no banco de dados
        $sql = "UPDATE pedidos SET cliente_id=?, sabor=?, tamanho=?, borda=?, massa=?, quantidade=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssii", $cliente_id, $sabor, $tamanho, $borda, $massa, $quantidade, $id);
        $stmt->execute();

        // Redireciona o usuário de volta para a lista de pedidos após atualizar
        header("Location: pedidos.php");
        exit();
    }
}

// Busca todos os clientes para preencher o select (permite trocar o cliente do pedido)
$clientes = $conn->query("SELECT id, nome FROM cliente ORDER BY nome");
?>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<h2>Editar Pedido</h2>

<!-- Formulário para edição do pedido com dados já preenchidos -->
<form method="post">
    <select name="cliente_id" required>
        <!-- Deixa selecionado o cliente atual do pedido -->
        <?php while ($d = $clientes->fetch_assoc()): ?>
            <option value="<?= $d['id'] ?>" <?= $d['id'] == $pedido['cliente_id'] ? 'selected' : '' ?>><?= htmlspecialchars($d['nome']) ?></option>
        <?php endwhile; ?>
    </select>
    <input name="sabor" placeholder="Sabor" value="<?= htmlspecialchars($pedido['sabor']) ?>" required>
    <input name="tamanho" placeholder="Tamanho (P, M, G)" value="<?= htmlspecialchars($pedido['tamanho']) ?>" required>
    <input name="borda" placeholder="Borda" value="<?= htmlspecialchars($pedido['borda'] ?? '') ?>">
    <input name="massa" placeholder="Massa" value="<?= htmlspecialchars($pedido['massa'] ?? '') ?>">
    <input type="number" name="quantidade" required placeholder="Quantidade" value="<?= htmlspecialchars($pedido['quantidade'] ?? '') ?>">
    <button>Salvar</button>
</form>

<!-- Link para voltar à página de listagem de pedidos -->
<a href="pedidos.php">Voltar</a>
