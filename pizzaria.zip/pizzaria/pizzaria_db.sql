CREATE DATABASE IF NOT EXISTS pizzaria_db CHARACTER SET utf8;
USE pizzaria_db;

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL
);

CREATE TABLE cliente (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  cpf VARBINARY(255) NOT NULL,   -- criptografado com AES_ENCRYPT
  telefone VARCHAR(20),
  email VARCHAR(100)
);

CREATE TABLE pedidos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT NOT NULL,
  sabor VARCHAR(100) NOT NULL,
  tamanho VARCHAR(20) NOT NULL,
  borda VARCHAR(50),
  massa VARCHAR(50),
  quantidade INT,
  FOREIGN KEY (cliente_id) REFERENCES cliente(id) ON DELETE CASCADE
);

CREATE TABLE entregas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT NOT NULL,
  data DATE NOT NULL,
  descricao VARCHAR(255) NOT NULL,
  valor DECIMAL(10,2) DEFAULT 0,
  FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE
);

-- Usuário de teste: admin / admin123
INSERT INTO usuarios (nome, senha) VALUES ('admin', '$2y$10$Njbx7zzkSCzsjp6H8QZsXOP8PMeTHE1t1jRch2S1lEHQawfopGSES');
-- Gere o hash com: php -r "echo password_hash('admin123', PASSWORD_DEFAULT);"
