<?php

// Inicia a sessão para verificar se o usuário está autenticado
session_start();

// Se não houver usuário logado, redireciona para a página de login
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit();
}

// Verifica o tempo de expiração da sessão: se ficou mais de 30 minutos sem usar o sistema,
// encerra a sessão e volta para o login avisando que expirou
if (time() - $_SESSION['ultimo_acesso'] > 30 * 60) {
    session_destroy();
    header('Location: login.php?expirou=1');
    exit();
}

// Ainda está no prazo: renova o horário do último acesso
$_SESSION['ultimo_acesso'] = time();

// Inclui o arquivo de configuração para conexão com o banco de dados
include 'config.php';

// Verifica se o formulário de cadastro foi enviado via POST e o botão 'add' foi clicado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    // Prepara uma consulta segura para inserir um novo pedido, evitando SQL Injection
    // O campo cliente_id liga o pedido ao seu cliente (um cliente tem muitos pedidos)
    $stmt = $conn->prepare(
        "INSERT INTO pedidos (cliente_id, sabor, tamanho, borda, massa, quantidade)
         VALUES (?, ?, ?, ?, ?, ?)"
    );
    // Liga os parâmetros enviados no formulário aos marcadores da consulta preparada
    $stmt->bind_param(
        "issssi",
        $_POST['cliente_id'],
        $_POST['sabor'],
        $_POST['tamanho'],
        $_POST['borda'],
        $_POST['massa'],
        $_POST['quantidade']
    );
    // Executa a inserção no banco
    $stmt->execute();
    // Após adicionar o pedido, redireciona para a mesma página para atualizar a lista
    header("Location: pedidos.php");
    exit();
}

// Recebe o termo de busca enviado via GET, ou vazio se não houver
$busca = $_GET['busca'] ?? '';

// Protege o termo de busca contra SQL Injection antes de colocar na consulta
$termo = $conn->real_escape_string($busca);

// Monta a cláusula WHERE da consulta para filtrar pedidos pelo sabor ou borda, se houver termo de busca
$where = $busca ? "WHERE c.sabor LIKE '%$termo%' OR c.borda LIKE '%$termo%'" : '';

// Consulta SQL que une pedidos e cliente (JOIN) para mostrar o nome do cliente de cada pedido
$query = "SELECT c.*, d.nome AS cliente_nome
          FROM pedidos c
          JOIN cliente d ON c.cliente_id = d.id
          $where
          ORDER BY c.sabor";

// Executa a consulta e armazena o resultado
$pedidos = $conn->query($query);

// Busca todos os clientes para preencher o select do formulário de cadastro
$clientes = $conn->query("SELECT id, nome FROM cliente ORDER BY nome");
?>
<!-- Folha de estilo padrão do sistema (todas as telas usam o mesmo arquivo css/style.css) -->
<link rel="stylesheet" href="css/style.css">

<h2>Cadastro de Pedido</h2>

<!-- Formulário para pesquisa de pedidos -->
<form method="get">
    <input name="busca" placeholder="Buscar por sabor ou borda..." value="<?= htmlspecialchars($busca) ?>">
    <button type="submit">Buscar</button>
    <a href="principal.php">Voltar</a>
</form>

<!-- Tabela exibindo os pedidos buscados/listados -->
<table border="1" cellpadding="5">
    <tr><th>Sabor</th><th>Tamanho</th><th>Borda</th><th>Massa</th><th>Qtd</th><th>Cliente</th><th>Ações</th></tr>
    <?php while($row = $pedidos->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($row['sabor']) ?></td>
        <td><?= htmlspecialchars($row['tamanho']) ?></td>
        <td><?= htmlspecialchars($row['borda'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['massa'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['quantidade'] ?? '') ?></td>
        <td><?= htmlspecialchars($row['cliente_nome']) ?></td>
        <td>
            <!-- Link para editar o pedido, passando o ID via GET -->
            <a href="editar_pedido.php?id=<?= $row['id'] ?>">Editar</a>
            <!-- Link para deletar o pedido, com confirmação (as entregas dele também são apagados) -->
            <a href="deletar_pedido.php?id=<?= $row['id'] ?>" onclick="return confirm('Excluir o pedido apaga também as entregas dele. Confirma?')">Excluir</a>
        </td>
      </tr>
    <?php endwhile; ?>
</table>

<!-- Formulário para cadastro de novo pedido -->
<h3>Novo pedido</h3>
<form method="post">
    <!-- Select com os clientes cadastrados: o valor enviado é o id do cliente -->
    <select name="cliente_id" required>
        <option value="">Selecione o cliente</option>
        <?php while ($d = $clientes->fetch_assoc()): ?>
            <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nome']) ?></option>
        <?php endwhile; ?>
    </select>
    <input name="sabor" required placeholder="Sabor">
    <input name="tamanho" required placeholder="Tamanho (P, M, G)">
    <input name="borda" placeholder="Borda">
    <input name="massa" placeholder="Massa">
    <input type="number" name="quantidade" required placeholder="Quantidade">
    <button name="add">Cadastrar</button>
</form>
